sudo dd if=zybo_linux/images/linux/petalinux-sdimage.wic of=/dev/mmcblk0 status=progress 

